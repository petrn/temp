#ifndef _USERDEF_H_
#define _USERDEF_H_


typedef     int             INT;       // 4 bytes

#ifdef IN
#undef IN
#endif

#ifdef OUT
#undef OUT
#endif

#ifndef NULL
#define NULL    ((void*)0)
#endif

#endif // _USERDEF_H_

