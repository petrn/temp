/**
 * API build.
 */
#define IT9510_Version_CONTROL     0x0000


/**
 * API version.
 */
#define IT9510_Version_NUMBER      0x0202


/**
 * API date.
 */
#define IT9510_Version_DATE        0x20170209
 
/**
 * API build.
 */
#define IT9510_Version_BUILD       0x00
